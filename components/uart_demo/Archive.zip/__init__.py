import esphome.codegen as cg
import esphome.config_validation as cv
from esphome import automation
from esphome.components import uart, binary_sensor, sensor, text_sensor
from esphome.const import CONF_ID, CONF_STATE, DEVICE_CLASS_VOLTAGE, ICON_FLASH, UNIT_VOLT

MULTI_CONF = True
DEPENDENCIES = ['uart']
AUTO_LOAD = ['binary_sensor', 'sensor', 'text_sensor']

uart_demo_ns = cg.esphome_ns.namespace('uart_demo')

CONF_UART_DEMO_ID = "UARTDemo_id"

UARTDemo = uart_demo_ns.class_('UARTDemo', cg.Component, uart.UARTDevice)

CONF_THE_TEXT = "the_text"
CONF_THE_SENSOR = "the_sensor"
CONF_THE_BINSENSOR = "the_binsensor"

CONFIG_SCHEMA = cv.Schema({
    cv.GenerateID(): cv.declare_id(UARTDemo),
    cv.Optional(CONF_THE_TEXT): text_sensor.text_sensor_schema(text_sensor.TextSensor),
    cv.Optional(CONF_THE_SENSOR): sensor.sensor_schema(
        unit_of_measurement=UNIT_VOLT,
        icon=ICON_FLASH,
        accuracy_decimals=1,
        device_class=DEVICE_CLASS_VOLTAGE
    ),
    cv.Optional(CONF_THE_BINSENSOR): binary_sensor.binary_sensor_schema(),
}).extend(uart.UART_DEVICE_SCHEMA)


async def to_code(config):
    var = cg.new_Pvariable(config[CONF_ID])
    await cg.register_component(var, config)
    await uart.register_uart_device(var, config)

    if CONF_THE_TEXT in config:
        sens = await text_sensor.new_text_sensor(config[CONF_THE_TEXT])
        cg.add(var.set_the_text(sens))

    if CONF_THE_SENSOR in config:
        sens = await sensor.new_sensor(config[CONF_THE_SENSOR])
        cg.add(var.set_the_sensor(sens))

    if CONF_THE_BINSENSOR in config:
        sens = await binary_sensor.new_binary_sensor(config[CONF_THE_BINSENSOR])
        cg.add(var.set_the_binsensor(sens))

